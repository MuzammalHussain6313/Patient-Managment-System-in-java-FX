/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterfaceLayer;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Muzammal Hussain
 */
public class SignUPController implements Initializable
{

    @FXML
    private Label Name;
    @FXML
    private Label errorLable;
    @FXML
    private ComboBox<?> userType;
    @FXML
    private Button SignUP;
    @FXML
    private TextField user;
    @FXML
    private TextField password;
    @FXML
    private TextField confarmPassword;
    @FXML
    private Button goBack;
    @FXML
    private AnchorPane mainAnchorPane;

    @FXML
    private void selectType(ActionEvent event)
    {
    }

    @FXML
    private void createNewUser(ActionEvent event)
    {
    }

    @FXML
    private void goBack(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("Login.fxml"));
	mainAnchorPane.getChildren().setAll(pane);
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
	// TODO
    }

}
