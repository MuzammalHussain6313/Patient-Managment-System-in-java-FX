/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterfaceLayer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.net.URL;
import java.util.ResourceBundle;

import BusinessLogicLayer.Patient;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import persistenceLayer.PatientDatabase;

/**
 * FXML Controller class
 *
 * @author Muzammal Hussain
 */
public class SearchPatientRecordController implements Initializable
{

    @FXML
    private TextField name;

    @FXML
    private TextField fathername;

    @FXML
    private Button searchPatientRecord;

    @FXML
    private Button cancel;

    @FXML
    private Label errorLable;

    @FXML
    void searchPatientRecord(ActionEvent event) {
        PatientDatabase patientDatabase = new PatientDatabase();
        Patient patient = new Patient();
        patient.setName(name.getText());
        patient.setFatherName(fathername.getText());
        patientDatabase.searchPatientRecord(patient);
    }
    @FXML
    void cencelSearch(ActionEvent event) {

    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
	// TODO
    }

}
