/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterfaceLayer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ChangePasswordController implements Initializable
{

    @FXML
    private Button changePassword;
    @FXML
    private Button cancel;
    @FXML
    private Label errorLable;

    @FXML
    private void ChangePassword(ActionEvent event)
    {
    }

    @FXML
    private void cancel(ActionEvent event)
    {
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
	// TODO
    }

}
