package UserInterfaceLayer;

import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class AdminController extends Application
{

    @FXML
    private MenuItem addNewpatient;
    @FXML
    private MenuItem searchPatientRocord;
    @FXML
    private MenuItem AddNewDoctor;
    @FXML
    private MenuItem AddNewDisease;
    @FXML
    private MenuItem deletePatientRecord;
    @FXML
    private MenuItem updatePatient;
    @FXML
    private MenuItem updateDoctor;
    @FXML
    private MenuItem searchPatientByName;
    @FXML
    private MenuItem searchPatientByID;
    @FXML
    private MenuItem searchPatientByAge;
    @FXML
    private MenuItem searchPatientByDisease;
    @FXML
    private MenuItem searchPatientByDoctor;
    @FXML
    private MenuItem searchDoctorByName;
    @FXML
    private MenuItem searchDoctorByDiseaseSpacialization;
    @FXML
    private MenuItem aboutUS;
    @FXML
    private MenuItem changePassword;
    @FXML
    private Button AddNewPatient;
    @FXML
    public static AnchorPane mainAnchorPane;
    @FXML
    private AnchorPane smallAnchorPane;
    @FXML
    private Button searchPatientRecord;
    @FXML
    private Button addNewDoctor;
    @FXML
    private Button print;

    @FXML
    private void addNewPatient(ActionEvent event) throws IOException
    {
//	AnchorPane arncherPaneForContent = FXMLLoader.load(getClass().getResource("NewPatient.fxml"));
//	smallAnchorPane.getChildren().setAll(arncherPaneForContent);
	try
	{
	    FXMLLoader loader = new FXMLLoader(getClass().getResource("NewPatient.fxml"));
	    Parent root = (Parent) loader.load();
	    Stage stage = new Stage();
	    stage.setScene(new Scene(root));
	    stage.show();
	} catch (Exception e)
	{
	    System.err.println(e.getClass().getName() + ": " + e.getMessage());
	    System.out.println("Exception occured.");
	}
    }

    public static void run()
    {

    }
//
//    public void start(Stage primaryStage) throws IOException
//    {
//	AnchorPane mainAncherPane = FXMLLoader.load(getClass().getResource("Admin.fxml"));
//	mainAncherPane.getChildren().setAll(mainAncherPane);
//	Scene scene = new Scene(mainAncherPane);
//	primaryStage.setScene(scene);
//	primaryStage.show();
//    }
//
//    public static void main(String[] args)
//    {
//	launch(args);
//    }

    @FXML
    private void searchPatient(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchPatientRecord.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void addNewDoctor(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("AddNewDoctor.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void addNewDisease(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("AddNewDisease.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void deletePatient(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("deletePatientRecord.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void searchPatientByAge(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchPatientByAge.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void searchPatientByDisease(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchPatientByDisease.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void searchPatientByDoctor(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchPatientByDoctorName.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void searchDoctorByName(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchDoctorByName.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void searchDoctorByDiseaseSpacialization(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchDoctorByDiseaseName.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void aboutUS(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("aboutUS.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void changePassword(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("changePassword.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void searchPatientByID(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchPatientByID.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void searchPatientByName(ActionEvent event) throws IOException
    {
	AnchorPane pane = FXMLLoader.load(getClass().getResource("searchPatientByname.fxml"));
	smallAnchorPane.getChildren().setAll(pane);
    }

    @FXML
    private void Print(ActionEvent event)
    {
    }

    @FXML
    private void updatePatient(ActionEvent event)
    {
    }

    @FXML
    private void updateDoctor(ActionEvent event)
    {
    }

    @Override
    public void start(Stage primaryStage) throws Exception
    {
	try
	{
	    AnchorPane pane = FXMLLoader.load(getClass().getResource("Admin.fxml"));
	    mainAnchorPane.getChildren().setAll(pane);
	    Scene scene = new Scene(mainAnchorPane);
	    Stage stage = new Stage();
	    stage.setScene(scene);
	    stage.show();
	} catch (Exception e)
	{
	    System.err.println(e.getClass().getName() + ": " + e.getMessage());
	    System.out.println("Exception occured.");
	} //To change body of generated methods, choose Tools | Templates.
    }
}
