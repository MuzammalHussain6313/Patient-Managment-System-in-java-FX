/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserInterfaceLayer;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import persistenceLayer.PatientDatabase;

/**
 * FXML Controller class
 *
 * @author Muzammal Hussain
 */
public class SearchPatientByIDController implements Initializable
{
    @FXML
    private TextField id;
    @FXML
    private Button searchPatientByID;
    @FXML
    private Button cencelPatientSearch;
    @FXML
    private Label errorLable;

    @FXML
    private void searchPatientByID(ActionEvent event)
    {
        PatientDatabase patientDatabase = new PatientDatabase();
        patientDatabase.searchPatientByID(Integer.parseInt(id.getText()));
    }

    @FXML
    private void cencelPatientSearch(ActionEvent event)
    {
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
	// TODO
    }

}
