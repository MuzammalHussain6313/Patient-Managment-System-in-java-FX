package BusinessLogicLayer;

import java.util.Date;

public class Patient
{
    private int id;
    private String name;
    private String fatherName;
    private String gender;
    private java.sql.Date dateOfBirth;
    private Doctor doctor;
    private String diseaseHistory;
    private String prescription;
    public Patient()
    {

    }
    public Patient(String name,String fatherName,String gender,java.sql.Date dateOfBirth,Doctor doctor,String diseaseHistory, String prescription)
    {
        this.name = name;
        this.fatherName = fatherName;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.doctor = doctor;
        this.diseaseHistory = diseaseHistory;
        this.prescription = prescription;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public void setDiseaseHistory(String diseaseHistory) {
        this.diseaseHistory = diseaseHistory;
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }

    public void setDateOfBirth(java.sql.Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getid()
    {
        return id;
    }
    public String getName()
    {
        return name;
    }
    public String getFatherName()
    {
        return fatherName;
    }
    public String getGender()
    {
        return gender;
    }
    public Date getDateOfBirth()
    {
        //java.sql.Date sqlDate = new java.sql.Date(dateOfBirth.getTime());
        return dateOfBirth;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Doctor getDoctor()
    {
        return doctor;
    }
    public String getDiseaseHistory()
    {
        return diseaseHistory;
    }
    public String getPrescription()
    {
        return prescription;
    }
}
