package BusinessLogicLayer;

public class Disease
{
    private int id;
    private String name;
    private String discription;
    public Disease(){

    }
    public Disease(String name, String discription)
    {
        this.name = name;
        this.discription = discription;
    }

    public String getDiscription()
    {
        return discription;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
