package BusinessLogicLayer;

public class Doctor
{
    private int id;
    private String name;
    public Disease specialization = new Disease();

    public Doctor()
    {

    }
    public Doctor(String name,Disease disease)
    {
        this.name = name;
        this.specialization = disease;
    }

    public void setid(int id )
    {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setName(String name)
    {
        this.name = name;
    }
    public void setSpecialization(Disease disease)
    {
        this.specialization = disease;
    }
    public String getName()
    {
        return name;
    }
    public Disease getSpacialization()
    {
        return this.specialization;
    }
    public void getInfo(int id)
    {

    }
}
